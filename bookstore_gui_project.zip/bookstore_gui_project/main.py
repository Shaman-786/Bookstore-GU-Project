from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
from modules.dashboard import open_dashboard

def main_window():
    root = Tk()
    root.title("📚 Stylish Bookstore")
    root.geometry("800x600")
    root.configure(bg="#f0f4f7")

    # Title Label
    title = Label(root, text="Welcome to the Bookstore", font=("Helvetica", 22, "bold"), bg="#f0f4f7", fg="#333")
    title.pack(pady=30)

    # Open Dashboard Button
    Button(root, text="Open Store", command=lambda: open_dashboard(root), bg="#2b6777", fg="white",
           font=("Helvetica", 14), padx=20, pady=10).pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    main_window()
